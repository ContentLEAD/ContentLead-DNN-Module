﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;

using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Xml;
using System.IO;
using System.Web.Hosting;
using System.Diagnostics;

using System.Text;
using System.Text.RegularExpressions;
using System.Globalization;

using DotNetNuke;
using DotNetNuke.Security;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Services.Scheduling;

using System.Reflection;
using System.Security;
using System.Security.Permissions;
using Brafton;

public partial class DesktopModules_Brafton_View2 : DotNetNuke.Entities.Modules.PortalModuleBase
{
    //Connection properties
    public SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString());
    public SqlCommand cmd = new SqlCommand();

    //Application path variable
    public string appPath;

    //DNN Variables
    int intPortalID;
    int PageTabId;
    string checkDomain;

    //Local Variables
    public int checkBlogModule;
    public int checkFriendURLS;
    public int checkBlogCreated;
    public int checkNewsAPI;
    public int checkBaseUrl;
    public int checkLimit;
    public int checkBlogID;
    public Dictionary<string, int> checkAll = new Dictionary<string, int>();

    public string strip(string alias)
    {
        // invalid chars, make into spaces
        alias = Regex.Replace(alias, @"[^a-zA-Z0-9\s-]", "");
        // convert multiple spaces/hyphens into one space       
        alias = Regex.Replace(alias, @"[\s-]+", " ").Trim();
        // hyphens
        alias = Regex.Replace(alias, @"\s", "-");

        return alias;
    }

    public Dictionary<string, int> checks()
    {
        cmd.CommandText = "IF OBJECT_ID('Blog_Settings') IS NOT NULL select 1 else select 0";
        checkFriendURLS = ((int)cmd.ExecuteScalar());
        checkAll.Add("Friendly Urls", checkFriendURLS);

        cmd.CommandText = "IF OBJECT_ID('Blog_Blogs') IS NOT NULL SELECT 1 Else Select 0";
        checkBlogCreated = (int)cmd.ExecuteScalar();
        checkAll.Add("Blog", checkBlogCreated);

        cmd.CommandText = "IF (SELECT BaseUrl FROM Brafton WHERE content='1') IS NOT NULL SELECT 1 ELSE SELECT 0";
        checkBaseUrl = (int)cmd.ExecuteScalar();
        checkAll.Add("Base Url", checkBaseUrl);

        cmd.CommandText = "IF (SELECT Api FROM Brafton WHERE content='1') IS NOT NULL SELECT 1 ELSE SELECT 0";
        checkNewsAPI = (int)cmd.ExecuteScalar();
        checkAll.Add("News API", checkNewsAPI);

        cmd.CommandText = "IF (SELECT Limit FROM Brafton WHERE content='1') IS NOT NULL SELECT 1 ELSE SELECT 0";
        checkLimit = (int)cmd.ExecuteScalar();
        checkAll.Add("Limit", checkLimit);

        cmd.CommandText = "IF (SELECT count(*) as total_record FROM DesktopModules WHERE FriendlyName = 'blog') > 0 Select 1 else select 0";
        checkBlogModule = ((int)cmd.ExecuteScalar());
        checkAll.Add("Blog Module", checkBlogModule);

        cmd.CommandText = "If (SELECT count(*) as total_record FROM Brafton WHERE BlogId >= 1) > 0 Select 1 else select 0";
        checkBlogID = ((int)cmd.ExecuteScalar());
        checkAll.Add("Blog ID", checkBlogID);

        return checkAll;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            //Get current directory for style sheets and images
            appPath = HttpRuntime.AppDomainAppVirtualPath == "/" ? appPath = "" : appPath = HttpRuntime.AppDomainAppVirtualPath;

            connection.Open();
            cmd.Connection = connection;

            //Showing your current portal ID
            intPortalID = PortalSettings.PortalId;
            currentPortalID.Text = intPortalID.ToString();

            //Showing your current TabID
            PageTabId = PortalSettings.ActiveTab.TabID;
            currentTabID.Text = PortalSettings.ActiveTab.TabID.ToString();

            //Get your current domain to insert into database for error checking
            checkDomain = HttpContext.Current.Request.Url.Host;

            Dictionary<string, int> checkAll = checks();

            #region SetsOnPageLoad
            //Sets the current PortalID in the Brafton Table
            cmd.CommandText = "IF Exists (SELECT * FROM Brafton WHERE content='1') UPDATE Brafton SET PortalId = " + intPortalID + " WHERE Content = '1' else INSERT INTO Brafton (Content, PortalId) VALUES (1, '" + intPortalID + "')";
            cmd.ExecuteNonQuery();

            //Sets the current TabID in the Brafton Table
            cmd.CommandText = "IF Exists (SELECT * FROM Brafton WHERE content='1') UPDATE Brafton SET TabId = " + PageTabId + " WHERE Content = '1' else INSERT INTO Brafton (Content, TabId) VALUES (1, '" + PageTabId + "')";
            cmd.ExecuteNonQuery();

            //Sets the current domain in the Brafton Table
            cmd.CommandText = "IF Exists (SELECT * FROM Brafton WHERE content='1') UPDATE Brafton SET DomainName = 'http://" + checkDomain + "' WHERE Content = '1' else INSERT INTO Brafton (Content, DomainName) VALUES (1, 'http://" + checkDomain + "')";
            cmd.ExecuteNonQuery();
            #endregion

            if (checkAll["Friendly Urls"] == 1)
            {
                boolFriendURL.Text = "True";
                boolFriendURL.CssClass = "boolTrue";
            }
            else
            {
                boolFriendURL.Text = "False";
                boolFriendURL.CssClass = "boolFalse";
            }

            if (checkAll["Blog Module"] == 1)
            {
                boolBlogModule.Text = "True";
                boolBlogModule.CssClass = "boolTrue";
                cmd.CommandText = "IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='Blog_Entries' AND column_name='BraftonID') BEGIN ALTER TABLE Blog_Entries ADD BraftonID nvarchar(255) END";
                cmd.ExecuteNonQuery();
            }
            else
            {
                boolBlogModule.Text = "False";
                boolBlogModule.CssClass = "boolFalse";
            }

            if (checkAll["Blog"] == 1)
            {
                boolBlogCreated.Text = "True";
                boolBlogCreated.CssClass = "boolTrue";

                cmd.CommandText = "Select Title From Blog_Blogs where PortalID = '" + intPortalID + "'";
                SqlDataReader blogOptions = cmd.ExecuteReader();

                if (!IsPostBack && blogOptions.HasRows)
                {
                    while (blogOptions.Read())
                    {
                        blogIdDrpDwn.Items.Add(new ListItem(blogOptions.GetString(0)));
                    }
                }

                blogOptions.Close();
                setAPIPH.Visible = true;
            }
            else
            {
                boolBlogCreated.Text = "False";
                boolBlogCreated.CssClass = "boolFalse";
            }

            if (checkAll["News API"] == 0)
            {
                boolCheckAPI.Text = "False";
                boolCheckAPI.CssClass = "boolFalse";
                nextStep.Visible = false;
            }
            else
            {
                cmd.CommandText = "SELECT Api FROM Brafton WHERE content='1'";
                string newsAPI = (string)cmd.ExecuteScalar();
                boolCheckAPI.Text = "<span class='boolTrue'>True</span>";
                apiURLLabel.Text = newsAPI;
                if (checkAll["Base Url"] == 1)
                {
                    nextStep.Visible = true;
                }
            }

            if (checkAll["Base Url"] == 0)
            {
                boolCheckUrl.Text = "False";
                boolCheckUrl.CssClass = "boolFalse";
            }
            else
            {
                cmd.CommandText = "SELECT BaseUrl FROM Brafton WHERE content='1'";
                string newsAPI = (string)cmd.ExecuteScalar();
                boolCheckUrl.Text = "<span class='boolTrue'>True</span>";
                baseURLLabel.Text = newsAPI;
            }

            if (checkAll["Limit"] == 1)
            {
                cmd.CommandText = "SELECT Limit FROM Brafton WHERE content='1'";
                limitLabel.Text = cmd.ExecuteScalar().ToString();
            }

            if (checkAll["Blog ID"] == 0)
            {
                boolCheckBlogID.Text = "<span class='boolFalse'>False</span>";
            }
            else
            {
                boolCheckBlogID.Text = "<span class='boolTrue'>True</span>";
                cmd.CommandText = "Select Title From Blog_Blogs Where BlogID = " + getBlogID();
                string blogTitle = (string)cmd.ExecuteScalar();
                currentBlogID.Text = blogTitle;
            }

            if (checkAll.Values.Sum() == 7)
            {
                Import.Visible = true;
            }

            connection.Close();
            cmd.Dispose();
        }
        catch (Exception ex)
        {
            labelError.Text = "Generic exception: " + ex.ToString();
            connection.Close();
            cmd.Dispose();
        }
    }

    #region GetAndSetBlock
    ///////////////////GET AND SET BLOG ID//////////////////////////
    protected void setBlogID_Click(object sender, EventArgs e)
    {
        connection.Open();
        int findBlogID;
        string test = blogIdDrpDwn.Text;
        cmd.CommandText = "IF OBJECT_ID('Blog_Blogs') IS NOT NULL(Select BlogID FROM Blog_Blogs Where title = '" + blogIdDrpDwn.Text + "') Else select 0";
        findBlogID = (int)cmd.ExecuteScalar();

        if (findBlogID != 0)
        {
            cmd.CommandText = "UPDATE Brafton SET BlogId = " + findBlogID + " WHERE Content = '1'";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "Select Title From Blog_Blogs Where BlogID = " + getBlogID();
            string blogTitle = (string)cmd.ExecuteScalar();
            currentBlogID.Text = blogTitle;

            //Set Check Blog ID Label = "TRUE"
            boolCheckBlogID.Text = "<span class='boolTrue'>True</span>";

            //Make import button visible
            Import.Visible = true;
        }
        connection.Close();
    }

    int getBlogID()
    {
        cmd.CommandText = "Select BlogId from Brafton Where Content = '1'";
        int blogID = (int)cmd.ExecuteScalar();
        return blogID;
    }

    ///////////////////GET AND SET Limit//////////////////////////
    protected void setLimit_Click(object sender, EventArgs e)
    {
        connection.Open();
        cmd.Connection = connection;

        try
        {

            cmd.CommandText = "IF OBJECT_ID('Brafton') IS NOT NULL(SELECT count(*) as total_record FROM Brafton WHERE content='1') ELSE SELECT 0";
            int limitAvail = (int)cmd.ExecuteScalar();

            if (limitAvail == 1 && Limit.Text != "")
            {
                cmd.CommandText = "UPDATE Brafton SET Limit = '" + Limit.Text + "' WHERE Content = '1'";
                cmd.ExecuteNonQuery();
                limitLabel.Text = Limit.Text;
            }
            else if (limitAvail == 0 && Limit.Text != "")
            {
                cmd.CommandText = "INSERT INTO Brafton (Content, Limit) VALUES (1, '" + Limit.Text + "' )";
                cmd.ExecuteNonQuery();
                limitLabel.Text = Limit.Text;
            }

        }
        catch (Exception ex)
        {
            labelError.Text = "Generic exception: " + ex.ToString();
        }
        connection.Close();
    }

    ///////////////////GET AND SET API KEY//////////////////////////
    protected void setAPI_Click(object sender, EventArgs e)
    {
        string newsURL = apiURL.Text;
        connection.Open();
        cmd.Connection = connection;

        try
        {

            cmd.CommandText = "IF OBJECT_ID('Brafton') IS NOT NULL(SELECT count(*) as total_record FROM Brafton WHERE content='1') ELSE SELECT 0";
            int apiAvail = (int)cmd.ExecuteScalar();

            if (apiAvail == 1 && apiURL.Text != "")
            {
                cmd.CommandText = "UPDATE Brafton SET Api = '" + newsURL + "' WHERE Content = '1'";
                cmd.ExecuteNonQuery();
                apiURLLabel.Text = newsURL;
                boolCheckAPI.Text = "<span class='boolTrue'>True</span>";
            }
            else if (apiAvail == 0 && apiURL.Text != "")
            {
                cmd.CommandText = "INSERT INTO Brafton (Content, Api) VALUES (1, '" + newsURL + "' )";
                cmd.ExecuteNonQuery();
                apiURLLabel.Text = newsURL;
                boolCheckAPI.Text = "<span class='boolTrue'>True</span>";
            }

            if (checkAll["Base Url"] == 1)
            {
                nextStep.Visible = true;
            }
        }
        catch (Exception ex)
        {
            labelError.Text = "Generic exception: " + ex.ToString();
        }
        connection.Close();

    }

    public string getNewsURL()
    {
        cmd.CommandText = "SELECT Api FROM Brafton WHERE content='1'";
        string feedURL = cmd.ExecuteScalar().ToString();
        return feedURL;
    }

    ///////////////////GET AND SET Base URL//////////////////////////
    protected void setBaseURL_Click(object sender, EventArgs e)
    {
        string newBaseURL = baseURL.Text;
        connection.Open();
        cmd.Connection = connection;

        try
        {
            cmd.CommandText = "IF OBJECT_ID('Brafton') IS NOT NULL(SELECT count(*) as total_record FROM Brafton WHERE content='1') ELSE SELECT 0";
            int apiAvail = (int)cmd.ExecuteScalar();

            if (apiAvail == 1 && baseURL.Text != "")
            {
                cmd.CommandText = "UPDATE Brafton SET BaseUrl = '" + newBaseURL + "' WHERE Content = '1'";
                cmd.ExecuteNonQuery();
                baseURLLabel.Text = newBaseURL;
                boolCheckUrl.Text = "<span class='boolTrue'>True</span>";
            }
            else if (apiAvail == 0 && baseURL.Text != "")
            {
                cmd.CommandText = "INSERT INTO Brafton (Content, BaseUrl) VALUES (1, '" + newBaseURL + "' )";
                cmd.ExecuteNonQuery();
                baseURLLabel.Text = newBaseURL;
                boolCheckUrl.Text = "<span class='boolTrue'>True</span>";
            }

        }
        catch (Exception ex)
        {
            labelError.Text = "Generic exception: " + ex.ToString();
        }
        connection.Close();
    }

    public string getBaseURL()
    {
        cmd.CommandText = "SELECT BaseUrl FROM Brafton WHERE content='1'";
        string baseURL = cmd.ExecuteScalar().ToString();
        return baseURL;
    }
    #endregion

    protected void Import_Click(object sender, EventArgs e)
    {
        Brafton.DotNetNuke.BraftonSchedule newSched = new Brafton.DotNetNuke.BraftonSchedule();
        newSched.DoWork();
        Response.Redirect(Request.RawUrl);
    }

}


