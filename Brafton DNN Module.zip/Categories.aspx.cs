﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Configuration;
using System.Collections;
using System.Data.SqlClient;
using System.Data;

public partial class DesktopModules_Brafton_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        GenerateGoogleSitemap();
    }

    // structure that represents a sitemap item
    struct SitemapItem
    {
        // public fields representing the sitemap item properties
        public string Url, ChangeFreq, Priority;

        // constructor initializes the fields
        public SitemapItem(string url, string changeFreq, string priority)
        {
            this.Url = url;
            this.ChangeFreq = changeFreq;
            this.Priority = priority;
        }
    }

    // generates the Google sitemap of the site
    private void GenerateGoogleSitemap()
    {
        // obtain the current HttpResponse object
        HttpResponse response = HttpContext.Current.Response;

        // set the content type
        response.ContentType = "text/xml";

        // use an XmlWriter to generate the Google sitemap
        XmlWriter xmlWriter = XmlWriter.Create(response.OutputStream);

        // write the start element
        xmlWriter.WriteStartElement("urlset", "http://www.sitemaps.org/schemas/sitemap/0.9");

        // obtain the list of sitemap items
        ArrayList sitemapItems = GetSitemapItems();

        // generate the sitemap items
        foreach (SitemapItem sitemapItem in sitemapItems)
        {
            // generate the <url> element and its contents
            xmlWriter.WriteStartElement("url");
            xmlWriter.WriteElementString("loc", sitemapItem.Url);
            xmlWriter.WriteElementString("changefreq", sitemapItem.ChangeFreq);
            xmlWriter.WriteElementString("priority", sitemapItem.Priority);
            xmlWriter.WriteEndElement();
        }

        // close the document 
        xmlWriter.WriteEndElement();
        xmlWriter.Flush();
    }

    // builds the list of items that need to be included in the sitemap
    private ArrayList GetSitemapItems()
    {
        // declare list of sitemap items
        //List<SitemapItem> sitemapItems = new List<SitemapItem>();
        //List<SitemapItem> sitemapItems = new List<SitemapItem>();
        string priority = "0.5";
        string changefreq = "daily";
        string permalink;

        SqlCommand command = new SqlCommand();
        SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString());
        DataTable tabIdDT = new DataTable();
        

        ArrayList sitemapItems = new ArrayList();

        string queryStringCats =
              "SELECT CatID, Slug From Blog_Categories";
        string queryStringBrafton = 
               "Select TabPath, TabID From Tabs Where TabID = (Select Date From Brafton Where Content='1')";

            command.Connection = connection;
            connection.Open();
            SqlDataAdapter tabIdAdapter = new SqlDataAdapter(queryStringBrafton, connection);
            tabIdAdapter.Fill(tabIdDT);

            command.CommandText = queryStringCats;
            SqlDataReader reader = command.ExecuteReader();

            // Call Read before accessing data.
            while (reader.Read())
            {
                permalink = "http://" + HttpContext.Current.Request.Url.Host + tabIdDT.Rows[0].ItemArray[0].ToString().Substring(1) + "/tabid/" + tabIdDT.Rows[0].ItemArray[1] + "/catid/" + reader.GetInt32(0) + "/" + reader.GetString(1);
            // create the list of URLs to include in the sitemap
        sitemapItems.Add(new SitemapItem(
          permalink, changefreq, priority));
            }

            // Call Close when done reading.
            reader.Close();
            connection.Close();
            tabIdDT.Dispose();
        

        // return the list of Sitemap objects
        return sitemapItems;
    } 
}