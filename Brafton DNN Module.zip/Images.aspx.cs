﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Configuration;
using System.Collections;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

public partial class DesktopModules_Brafton_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        GenerateGoogleSitemap();
    }

    // structure that represents a sitemap item
    struct SitemapItem
    {
        // public fields representing the sitemap item properties
        public string Url, _relativeUrl;

        // constructor initializes the fields
        public SitemapItem(string url, string relativeUrl)
        {
            this.Url = url;
            this._relativeUrl = relativeUrl;
        }
    }

    // structure that represents a sitemap item
    struct SitemapImage
    {
        // public fields representing the sitemap item properties
        public string _imageUrl, _caption;

        // constructor initializes the fields
        public SitemapImage(string imageUrl, string caption)
        {
            if (caption == "")
            {
                this._imageUrl = imageUrl;
                this._caption = "false";
            }
            else
            {
                this._caption = caption;
                this._imageUrl = imageUrl;
            }
        }
    }

    // generates the Google sitemap of the site
    private void GenerateGoogleSitemap()
    {
        // obtain the current HttpResponse object
        HttpResponse response = HttpContext.Current.Response;

        // set the content type
        response.ContentType = "text/xml";

        // use an XmlWriter to generate the Google sitemap
        XmlWriter xmlWriter = XmlWriter.Create(response.OutputStream);

        // write the start element
        xmlWriter.WriteStartElement("urlset", "http://www.sitemaps.org/schemas/sitemap/0.9");
        xmlWriter.WriteAttributeString("xmlns", "image", null, "http://www.google.com/schemas/sitemap-image/1.1");

        // obtain the list of sitemap items
        ArrayList sitemapItems = GetSitemapItems();       

        // generate the sitemap items
        foreach (SitemapItem sitemapItem in sitemapItems)
        {
            // generate the <url> element and its contents
            xmlWriter.WriteStartElement("url");
            xmlWriter.WriteElementString("loc", sitemapItem.Url);
            ArrayList sitemapImages = GetImages(sitemapItem._relativeUrl);
            foreach (SitemapImage sitemapImage in sitemapImages)
            {
                xmlWriter.WriteStartElement("image", "http://www.google.com/schemas/sitemap-image/1.1");
                xmlWriter.WriteElementString("loc", "http://www.google.com/schemas/sitemap-image/1.1", sitemapImage._imageUrl);
                if (sitemapImage._caption != "false")
                {
                    xmlWriter.WriteElementString("caption", "http://www.google.com/schemas/sitemap-image/1.1", sitemapImage._caption);
                }
                xmlWriter.WriteEndElement();
            }
            xmlWriter.WriteEndElement();
        }

        // close the document 
        xmlWriter.WriteEndElement();
        xmlWriter.Flush();
    }

    // builds the list of items that need to be included in the sitemap
    private ArrayList GetSitemapItems()
    {

        string permalink;

        ArrayList sitemapItems = new ArrayList();

        string queryString =
        "SELECT PermaLink From Blog_Entries";

        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString()))
        {
            SqlCommand command =
                new SqlCommand(queryString, connection);
            connection.Open();

            SqlDataReader reader = command.ExecuteReader();

            // Call Read before accessing data.
            while (reader.Read())
            {
                if (reader.GetString(0).Contains(HttpContext.Current.Request.Url.Host))
                {
                    permalink = reader.GetString(0);
                }
                else
                {
                    permalink = "http://" + HttpContext.Current.Request.Url.Host + reader.GetString(0);
                }

                // create the list of URLs to include in the sitemap
                sitemapItems.Add(new SitemapItem(permalink, reader.GetString(0)));
            }

            // Call Close when done reading.
            reader.Close();
        }



        // return the list of Sitemap objects
        return sitemapItems;
    }

    private ArrayList GetImages(string permalink)
    {

        string imageSrc;
        string caption;
        string description;
        const string regexImg = @"<img[^>]*?(alt\s*=\s*[""']?([^'"">]+?)?['""][^>]*?)?src\s*=\s*[""']?([^'"">]+?)['""][^>]*?>";


        ArrayList sitemapItems = new ArrayList();

        string queryString =
        "SELECT Entry From Blog_Entries WHERE PermaLink = '" + permalink + "'";

        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString()))
        {
            SqlCommand command =
                new SqlCommand(queryString, connection);
            connection.Open();

            description = command.ExecuteScalar().ToString();
            description = HttpUtility.HtmlDecode(description);

                MatchCollection matchesImg = Regex.Matches(description, regexImg, RegexOptions.IgnoreCase | RegexOptions.Singleline);

                foreach (Match m in matchesImg)
                {
                    if (m.Groups[3].Value.ToString().Contains(HttpContext.Current.Request.Url.Host))
                    {
                        imageSrc = "http://" + HttpContext.Current.Request.Url.Host + m.Groups[3].Value;
                    }
                    else
                    {
                        imageSrc = "http://" + HttpContext.Current.Request.Url.Host + m.Groups[3].Value;
                    }
                        caption = m.Groups[2].Value;

                        sitemapItems.Add(new SitemapImage(imageSrc, caption));
                }
                
            }

        // return the list of Sitemap objects
        return sitemapItems;
    }
}